/**
 * Types related to mouse callbacks functionality
 * @author Dan Nirel
 */
package danogl.gui.mouse;